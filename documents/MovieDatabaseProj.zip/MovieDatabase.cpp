/*********
MovieDatabase
Date: 5/1/2021
Description: This program creates a movie database from a pre-existing file.
			 The program reads the contents of the file and stores it in a
			 dynamically allocated array. The user inputs the file name to
			 be read, then if the file successfully opens, asks the user for
			 a movie name they would like to search for. The program displays
			 the movie information if found in the database and asks the user
			 if they would like to save the movie in a favorites text file.
			 The program then keeps prompting the users if they would like to
			 repeat. if they choose to exit, displays all the saved movies.
			 Program cleans the heap at the end.
*********/

#include<iostream>
#include<string>
#include<cstring>
#include<fstream>
#include<iomanip>
#include<cstdlib>

using namespace std;

//struct declaration
struct Movie {
	string title;
	double grossTotal;
	string director;
	string releaseDate;
	int runTime;
};

//function prototypes
int numberOfLines(ifstream&);
void populateMovieFromFile(ifstream&, Movie&);
void displayMovie(const Movie&);
Movie* createDatabase(int&);
bool caseInsensitiveCmp(string, string);
void findMovie(Movie*, int);
void saveToFile(const Movie&);
bool promptToContinue();
void displayFavorites();


// ======================
//     main function
// ======================
int main() {

	//this variable is given a value in createDatabase
	int numMovies;

	bool contPrompt = true;

	//initialization of movPtr pointer value
	Movie* movPtr = createDatabase(numMovies);

	//loops through the findMovie until user wishes to exit
	while (contPrompt) {
		findMovie(movPtr, numMovies);
		contPrompt = promptToContinue();
	}
	displayFavorites();

	//cleaning of the array in the heap
	delete[] movPtr;

	return 0;
}

// ======================
//      numberOfLines
// receives an input filestream file by reference
// returns the number of lines in the file opened by the user
// This function receives an open ifstream variable and uses a
// while loop to get each line of the text file, incrementing size
// each time it successfully does a getline
// ======================
int numberOfLines(ifstream& movieFile) {
	int size = 0;
	string temp;
	if (movieFile) {

		//increments size every time getline successfully executes
		while (getline(movieFile, temp))
			size++;
	}
	movieFile.close();
	return size;
}

// ======================
//      populateMovieFromFile
// receives an input file and a Movie object by reference
// returns nothing as it is void
// This function populates one single movie object when called
// ======================
void populateMovieFromFile(ifstream& movieFile, Movie& movie) {
	string temp;
	getline(movieFile, movie.title, ',');
	getline(movieFile, temp, ',');

	//conversion of string to double using stod
	movie.grossTotal = stod(temp);

	getline(movieFile, movie.director, ',');
	getline(movieFile, movie.releaseDate, ',');
	getline(movieFile, temp);

	//conversion of string to integer using stoi
	movie.runTime = stoi(temp);
}

// ======================
//      displayMovie
// receives a Movie object by constant reference
// returns nothing as it is void
// This function displays each element of a single Movie object
// in a formatted function using setw and left right alignments
// ======================
void displayMovie(const Movie& movie) {
	cout << endl;
	cout << right << setw(15) << "Title: " << left << movie.title << endl;
	cout << right << setw(15) << "Gross Total: ";
	cout << left << movie.grossTotal << " billion dollars" << endl;
	cout << right << setw(14) << "Director:";
	cout << left << movie.director << endl;
	cout << right << setw(14) << "Release Date:";
	cout << left << movie.releaseDate << endl;
	cout << right << setw(15) << "Runtime: ";
	cout << left << movie.runTime << " minutes" << endl;
	cout << endl;
}

// ======================
//      createDatabase
// receives an integer variable by reference
// returns a pointer to the dynamically allocated array of Movie objects
// This function prompts the user to enter an input file name and if the file
// cannot be opened, displays an error message. After the file is opened, the
// function then calls the numberOfLines function to determine the number of
// elements for the creation of a dynamically allocated array. Then the
// function loops through the newly created array and calls the
// populateMovieFromFile function to store a movie in each index.
// ======================
Movie* createDatabase(int& numMovies) {
	string fileName;
	ifstream movFile;

	//loop to validate filename
	do {
		cout << "Please enter filename: ";
		cin >> fileName;
		movFile.open(fileName);
		if (movFile.fail()) {
			cout << "error: file does not exist. ";
			cout << "Please enter a valid filename";
			cout << endl;
		}
	} while (movFile.fail());

	numMovies = numberOfLines(movFile);
	//file is closed at the end of numberOfLines

	//dynamic allocation of movie database array
	Movie* movPtr = new Movie[numMovies];

	//reopens the file to start from line 0
	movFile.open(fileName);
	for (int i = 0; i < numMovies; i++) {
		populateMovieFromFile(movFile, movPtr[i]);
	}

	movFile.close();

	//returns pointer to dynamically allocated array
	return movPtr;

}

// ======================
//      caseInsensitiveCmp
// receives a string variable of user input and a movie title from array
// returns boolean value of true if both strings are equal and false otherwise
// This function compares two strings by performing a non-case sensitive
// comparison
// ======================
bool caseInsensitiveCmp(string userInput, string movTitle) {

	if (userInput.length() != movTitle.length()) {
		return false;
	}
	else if (userInput.length() == movTitle.length()) {

		//loop to convert all characters of both strings to lower case
		for (int i = 0; i < movTitle.length(); i++) {
			userInput[i] = tolower(userInput[i]);
			movTitle[i] = tolower(movTitle[i]);
		}

		//if both lower case strings are not exactly equal
		if (userInput != movTitle) {
			return false;
		}
	}

	return true;
}

// ======================
//      findMovie
// receives a pointer to an array of Movie objects and
// an integer variable of the number of movies
// returns nothing as it is void
// This function prompts the user to enter a movie title to search for
// and searches through the array of Movie objects until
// caseInsensitiveCmp return true or loop reaches end
// ======================
void findMovie(Movie* movPtr, int numMovies) {
	string movieName;
	int i = 0;
	bool match = false;
	char savePrompt;

	cout << endl;
	cout << "Enter a movie title to search for: ";
	cin.ignore();
	getline(cin, movieName);

	//loop that compares all movie titles with userInput
	// If a title matches, exits the loop
	for (i; i < numMovies; i++) {
		match = caseInsensitiveCmp(movieName, movPtr[i].title);
		if (match) {
			break;
		}
	}

	if (match) {
		//displayMovie is called to output the movie details on the screen
		displayMovie(movPtr[i]);
		cout << "Would you like to save the above movie? (Y / N): ";
		cin >> savePrompt;
		savePrompt = tolower(savePrompt);

		if (savePrompt == 'y') {
			saveToFile(movPtr[i]);
			cout << "Successfully saved to favorites.txt!";
			cout << endl;
		}

		else {
			cout << "Movie not saved" << endl;
		}
	}
	else {
		cout << endl;
		cout << right << setw(15) << "Error: ";
		cout << left << "'" << movieName;
		cout << "' not found in database. Please try again." << endl;
	}

}

// ======================
//      saveToFile
// receives a Movie object by constant reference
// returns nothing as it is void
// This function saves the specified movie object in a text file
// called "favorites.txt"
// ======================
void saveToFile(const Movie& movie) {

	//static variable is declared so value remains
	static bool first = 0;
	ofstream movieFav;
	if (first == 0) {
		first = 1;
		movieFav.open("favorites.txt");
	}
	else {

		//movie is closed so it starts from line 0
		movieFav.close();

		//input file is opened but new contents are appended to the end
		movieFav.open("favorites.txt", ios::app);
	}

	movieFav << right << setw(15) << "Title: ";
	movieFav << left << movie.title << endl;
	movieFav << right << setw(15) << "Gross Total: ";
	movieFav << left << movie.grossTotal << " billion dollars" << endl;
	movieFav << right << setw(14) << "Director:";
	movieFav << left << movie.director << endl;
	movieFav << right << setw(14) << "Release Date:";
	movieFav << left << movie.releaseDate << endl;
	movieFav << right << setw(15) << "Runtime: ";
	movieFav << left << movie.runTime << " minutes" << endl;
	movieFav << endl;
}

// ======================
//      promptToContinue
// receives nothing
// returns a boolean value of false if the user decides to quit the
// program and true otherwise
// This function determines whether or not the user wants to continue
// using the program by prompting the user for a Y/N
// ======================
bool promptToContinue() {
	char contPrompt = 'n';
	cout << endl;
	cout << "Would you like to exit? (Y / N): ";
	cin >> contPrompt;

	//case insensitive conversion
	contPrompt = tolower(contPrompt);
	if (contPrompt == 'y') {
		return false;
	}
	else {
		return true;
	}
	cout << endl;
}

// ======================
//      displayFavorites
// receives nothing
// returns nothing as it is void
// This function will display all saved favorite movies by displaying
// all the information in the favorites.txt file.
// If there is no favorites.txt file it will display an error
// Otherwise, it will simply display all saved movies
// ======================
void displayFavorites() {
	ifstream favMovies;
	string currLine;
	favMovies.open("favorites.txt");

	//if favorties.txt does not exist
	if (favMovies.fail()) {
		cout << endl;
		cout << right << setw(15) << "Error: ";
		cout << left << "There are no saved movies in favorites.";
		cout << endl;
	}
	//if favorites.txt can be opened
	else {
		cout << endl << endl;
		cout << "Your saved movies are: ";
		cout << endl << endl;
		while (getline(favMovies, currLine)) {
			cout << currLine << endl;
		}
		favMovies.close();
	}
}

// ======================
//     Sample Run
// ======================
/*
Please enter filename: movies.txt

Enter a movie title to search for: AvaTar

		Title: Avatar
  Gross Total: 2.788 billion dollars
	 Director: James Cameron
 Release Date: 12/18/09
	  Runtime: 161 minutes

Would you like to save the above movie? (Y / N): y
Successfully saved to favorites.txt!

Would you like to exit? (Y / N): n

Enter a movie title to search for: FINDING dory

		Title: Finding Dory
  Gross Total: 1.029 billion dollars
	 Director: Andrew Stanton
 Release Date: 6/17/16
	  Runtime: 97 minutes

Would you like to save the above movie? (Y / N): Y
Successfully saved to favorites.txt!

Would you like to exit? (Y / N): N

Enter a movie title to search for: jurassic word

		Error: 'jurassic word' not found in database. Please try again.

Would you like to exit? (Y / N): y


Your saved movies are:

		Title: Avatar
  Gross Total: 2.788 billion dollars
	 Director: James Cameron
 Release Date: 12/18/09
	  Runtime: 161 minutes

		Title: Finding Dory
  Gross Total: 1.029 billion dollars
	 Director: Andrew Stanton
 Release Date: 6/17/16
	  Runtime: 97 minutes


C:\Users\JohnDoe\Documents\22B solutions\Assignment 3\Debug\Assignment 3.exe (process 5720) exited with code 0.
Press any key to close this window . . .
*/
