ASSIGNMENT 6 Osbert Reynaldi Sudjana

Part 1

This assignment deals with a custom exception handler that detects a missing grade.
It detects the missing 5th score of any student record and fixes it by changing it to 0, assuming the student did not do the test
The file path for this part is set to "StudentRecordError.txt" outside the source file, which contains 40 records with one of them having a missing 5th quiz score
In the demonstration within the driver1 class, the output detects the missing grade, putting a 0 in place of the space in the output and therefore,
The student's score for quiz 5 is 0. An error message along with the number is also output to the screen and written to a text file called Error_log.txt

Part 2

This assignment deals with serialisation. By implementing serialisation on the Student class and statistics class, as well as the StudentGrade class,
StudentGrade objects are able to be serialised. Each student will have their own serialised file in the format of "sid.txt" containing binary forms of their student id, grades for each quiz, as well as statistics for the class; including high, low, and average scores for each test
The user is prompted for a text file to read which can either be StudentRecords0.txt to StudentRecords4.txt. 
Each of these files contains different amounts of student records, so to see the demonstration of the serialisation, it is advised to go from StudentRecords0.txt to StudentRecords4.txt in ascending order
The output displays the contents of the file, as well as the student grades of the specific student id inputted by the user

Part 3

This assignment deals with the implementation of interfaces and abstract classes. This is demonstrated using StudentAPI interface, implemented onto the StudentAPIImpl abstract class which extends to the SAPI class.
The StudentAPIImpl class contains a constructor which reads the "StudentRecords3.txt" file; containing 40 records. The constructor also serialises the 40 student records into .ser files so this part should be done after the other 2 parts. 
The implementation of the API and abstract class makes the Driver3 very simple, but does almost the same thing as part 2 which demonstrates the power of APIs.


FILES INCLUDED:
	
	README.txt
	ASSIGNMENT_6_CLASS_DIAGRAMS.pdf
	Assignment 6 Part 1 Design.txt
	Assignment 6 part 2 Design.txt
	Assignment 6 part 3 Design.txt
	src:
		Adapter (pkg):
			SAPI.java
			StudentAPI.java
			StudentAPIImpl.java
		driver (pkg):
			Driver1.java
			Driver2.java
			Drover3.java
		Exception (pkg):
			StudentGradeException.java
		model (pkg):
			Student.java
			Statistics.java
			StudentGrade.java
		util (pkg):
			FileIO.java
	StudentRecords0.txt
	StudentRecords1.txt
	StudentRecords2.txt
	StudentRecords3.txt
	StudentRecords4.txt
	StudentRecordError.txt
	Error_log.txt