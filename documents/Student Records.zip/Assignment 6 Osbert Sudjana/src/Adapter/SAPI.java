package Adapter;

public class SAPI extends StudentAPIImpl{

	public SAPI() {
		super();
	}
	
	public void printstats() {
		super.printstats();
	}
	
	public void printstudentscores(int sid) {
		super.printstudentscores(sid);
	}
}
