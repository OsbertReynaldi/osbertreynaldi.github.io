package Adapter;

public interface StudentAPI {
	public void printstats();
	public void printstudentscores(int sid);
}
