package Adapter;
import util.*;

import model.*;

public abstract class StudentAPIImpl implements StudentAPI{
	
	private Student[] studentArr = new Student[40];
	private Statistics stats = new Statistics();
	
	public StudentAPIImpl(){
		FileIO a1 = new FileIO();
		
		a1.readFile("StudentRecords3.txt", studentArr);

		stats.findlow(studentArr);

		stats.findhigh(studentArr);
		
		stats.findavg(studentArr);
		
		StudentGrade[] reports = new StudentGrade [40];
		
		for (int i = 0; i < studentArr.length; i++) {
			if (studentArr[i] == null) {
				break;
			}
			else {
				reports[i] = new StudentGrade (studentArr[i], stats);
			}

		}
		
		a1.serializeGrades(reports);
	}
	
	public void printstats() {
		stats.print();
	}
	
	public void printstudentscores(int sid) {
		FileIO f1 = new FileIO ();
		f1.deserializeGrades(sid);
	}

}
