package util;
import model.*;
import java.io.*;
import java.util.StringTokenizer;
import Exception.*;

public class FileIO{
	 private String fname;

	public FileIO() { 
		fname = "";
	}
	 
	public FileIO (String fname) {
		this.fname = fname;
	}
	
	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public void readFile(String filename, Student [] stu) {
		
		int counter = 0;
		try {
			FileReader file = new FileReader(filename);
			BufferedReader buff = new BufferedReader(file);
			boolean eof = false;
			while (!eof) {
				String line = buff.readLine();
				
				if (line == null || counter == 41) {
					eof = true;
				}
				
				else if (counter > 0){
					
					stu[counter-1] = new Student();
					StringTokenizer st = new StringTokenizer(line);
					
					int tokenNum = 0;
					
					while (st.hasMoreTokens()) {
					    int x = Integer.parseInt(st.nextToken()) ;
					    
					    if (tokenNum == 0)
					    	stu[counter-1].setSID(x);
					   
					    else
					    	stu[counter-1].setScores(tokenNum-1, x);
					    
					    tokenNum++;
				    }
					try {
						if (tokenNum <= 5 && !st.hasMoreTokens()) {
							throw new StudentGradingException (1, "Quiz 5 score was missing on Student ID " + stu[counter-1].getSID());
						}
					}
					catch (StudentGradingException e) {
						e.fix(1);
						stu[counter-1].setScores(tokenNum-1, 0);
					}
				}
				counter++;
			}
			buff.close();
		
		} 
		catch (IOException e) {
			System.out.printf("Error -- %s", e.toString());
			System.out.printf("\n");
		}
	}
	
	public void serializeGrades(StudentGrade [] a)
	{
		//Using a loop serialize each StudentGrade object.
		for (int i = 0; i < a.length; i++) {
			if (a[i] == null) {
				break;
			}
			else {
				int studentid = a[i].getStu().getSID();
				try {
					FileOutputStream f1 = new FileOutputStream (studentid + ".ser");
					ObjectOutputStream out = new ObjectOutputStream (f1);
					out.writeObject(a[i]);
					out.close();
				}catch (Exception e) {
					System.out.printf("Error -- %s\n", e.toString());
				}
			}
		}

	}
	
	public void deserializeGrades(int studid)
	{
		//deserialize the file with studid.
		try {
			FileInputStream f1= new FileInputStream(studid + ".ser");
			ObjectInputStream in = new ObjectInputStream (f1);
			StudentGrade report = (StudentGrade) in.readObject();
			report.print();
			in.close();
		}
		catch(FileNotFoundException e) {
			System.out.printf("Error -- Student Not Found\n");
		}
		
		catch(Exception e) {
			System.out.printf("Error -- %s\n", e.toString());
		}
	}


}
