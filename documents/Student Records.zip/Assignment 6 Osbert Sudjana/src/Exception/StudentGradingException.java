package Exception;
import java.io.*;

public class StudentGradingException extends Exception{
	private int errorno;
	private String errormsg;
	
	public StudentGradingException() {
		super();
		printmyproblem();
	}
	
	public StudentGradingException(String errormsg) {
		super();
		this.errormsg = errormsg;
		printmyproblem();
	}
	
	public StudentGradingException(int errorno) {
		super();
		this.errorno = errorno;
		printmyproblem();
	}
	
	public StudentGradingException(int errorno, String errormsg) {
		super();
		this.errorno = errorno;
		this.errormsg = errormsg;
		printmyproblem();
	}
	
	public int getErrorno() {
		return errorno;
	}
	
	public void setErrorno(int errorno) {
		this.errorno = errorno;
	}
	
	public String getErrormsg() {
		return errormsg;
	}
	
	public void setErrormsg(String errormsg) {
		this.errormsg = errormsg;
	}
	
	public void printmyproblem() {
		//for lab 6 open a text file in append mode and write a line with error # and message.
		System.out.printf("%s, assuming score to 0\n", errormsg);
		try {
			FileWriter f1 = new FileWriter ("Error_Log.txt", true);
			f1.write("errorno=" + errorno + ", " + errormsg + "\n");
			f1.close();
		}catch(IOException e) {
			System.out.printf("Error -- ", e.toString());
		}
	}

	public void fix(int errorno) {
		if (errorno == 1){
				fixProblemReadFromConsole(); 
		}
	}

	public String fixProblemReadFromConsole()
	{
		String a = "/Users/osbert/eclipse-workspace/Assignment 6/Error_Log.txt";
		System.out.printf("got here --> fixProblemReadFromConsole\n");
		return a;
	}
}
