package model;

import java.io.Serializable;

public class Statistics implements Serializable{
	private int [] lowscores = new int [5];

	private int [] highscores = new int [5];

	private float [] avgscores = new float [5];

	public void findlow(Student [] a) {

		for (int i = 0; i < 5; i++) {
			int lowestScore = 999;
			for (int j = 0; j < a.length; j++) {
				if (a[j] == null) {
					break;
				}
				else {
					if (a[j].getScores(i) < lowestScore) {
						lowestScore = a[j].getScores(i);
					}	
				}
			}
			lowscores[i] = lowestScore;
		}
		
	}

	public void findhigh(Student [] a) {
		
		for (int i = 0; i < 5; i++) {
			int highestScore = -1;
			for (int j = 0; j < a.length; j++) {
				if (a[j] == null) {
					break;
				}
				else {
					if (a[j].getScores(i) > highestScore) {
						highestScore = a[j].getScores(i);
					}
				}
			}
			highscores[i] = highestScore;
		}

	}

	public void findavg(Student [] a) {

		int j = 0;
		for(int i = 0; i < 5; i++) {
			float average = 0;
			for (j = 0; j < a.length; j++) {
				if (a[j] == null) {
					break;
				}
				else {
					average += a[j].getScores(i);
				}
			}
			
			if (j == 0) {
				average = -1;
			}
			else {
				average /= j;
			}
			
			avgscores[i] = average;
		 }

	}
	
	public void print() {
		if (lowscores[0] == 999) {
				System.out.printf("There are no available student records\n\n");
			}
 		else {
 			System.out.printf("Lowest Scores for each quiz are: ");
 			for (int i = 0; i < 5; i++) {
 				System.out.printf("%d   ", lowscores[i]);
 			}
 			System.out.printf("\n");
 			
 			System.out.printf("Highest Scores for each quiz are: ");
 			for (int i = 0; i < 5; i++) {
 				System.out.printf("%d   ", highscores[i]);
 			}
 			System.out.printf("\n");
 			
 			System.out.printf("Average Scores for each quiz are: ");
 			for (int i = 0; i < 5; i++) {
 				System.out.printf("%.1f   ", avgscores[i]);
 			}
 			System.out.printf("\n\n");
 		}
	}
	
	public void print(int option) {

	 switch(option) {
	 	case 1:{
	 		if (lowscores[0] == 999) {
 				System.out.printf("There are no available student records\n\n");
 				break;
 			}
	 		else {
	 			System.out.printf("Lowest Scores for each quiz are: ");
	 			for (int i = 0; i < 5; i++) {
	 				System.out.printf("%d   ", lowscores[i]);
	 			}
	 			System.out.printf("\n\n");
	 			break;
	 		}
	 	}
	 
	 	case 2:{
	 		if (highscores[0] == -1) {
 				System.out.printf("There are no available student records\n\n");
 				break;
 			}
	 		else {
	 			System.out.printf("Highest Scores for each quiz are: ");
	 			for (int i = 0; i < 5; i++) {
	 				System.out.printf("%d   ", highscores[i]);
	 			}
	 			System.out.printf("\n\n");
	 			break;
	 		}
	 	}
	 
	 	case 3:{
	 		if (avgscores[0] == -1) {
 				System.out.printf("There are no available student records\n\n");
 				break;
 			}
	 		else {
	 			System.out.printf("Average Scores for each quiz are: ");
	 			for (int i = 0; i < 5; i++) {
	 				System.out.printf("%.1f   ", avgscores[i]);
	 			}
	 			System.out.printf("\n\n");
	 			break;
	 		}
	 	}
	 	
	 	case 4:{
	 		print();
	 	}
	 	}
	}
}
