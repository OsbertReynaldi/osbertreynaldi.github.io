package model;
import java.io.*;

public class StudentGrade implements Serializable{
	private Student stu;
	private Statistics studentStats;
	
	public StudentGrade() {
		this.stu = null;
		this.studentStats = null;
	}
	
	public StudentGrade(Student stu, Statistics studentStats) {
		super();
		this.stu = stu;
		this.studentStats = studentStats;
	}

	public Student getStu() {
		return stu;
	}

	public void setStu(Student stu) {
		this.stu = stu;
	}

	public Statistics getStudentStats() {
		return studentStats;
	}

	public void setStudentStats(Statistics studentStats) {
		this.studentStats = studentStats;
	}
	
	public void print() {
		System.out.printf("\nStud\tQ1\tQ2\tQ3\tQ4\tQ5\n");
		stu.print();
		System.out.printf("\n");
		studentStats.print();
	}
}
