package model;

import java.io.Serializable;

public class Student implements Serializable{
	private int SID;

	private int scores[] = new int[5];
	
	public Student() {
		SID = 0;
		for (int i = 0; i < 5; i++) {
			scores[i] = 0;
		}
	}

	public Student(int sID, int[] scores) {
		SID = sID;
		this.scores = scores;
	}

	public int getSID() {
		return SID;
	}

	public void setSID(int sID) {
		SID = sID;
	}

	public int[] getScores() {
		return scores;
	}

	public void setScores(int[] scores) {
		this.scores = scores;
	}

	public int getScores(int i) {
		return scores[i];
	}
	
	public void setScores (int i, int score) {
		scores[i] = score;
	}

	public void print() {
	
		System.out.printf("%d", SID);
		for (int i = 0; i < 5; i++){
			System.out.printf("\t%d", scores[i]);
		}
		System.out.printf("\n");
	}
	
}
