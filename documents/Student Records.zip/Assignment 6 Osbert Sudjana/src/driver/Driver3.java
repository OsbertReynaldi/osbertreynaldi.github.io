package driver;
import Adapter.*;

public class Driver3 {

	public static void main(String[] args) {
		StudentAPI s1 = new SAPI();
		s1.printstats();
		s1.printstudentscores(1234);
	}

}

//SAMPLE RUN
/*Lowest Scores for each quiz are: 0   7   0   0   10   
Highest Scores for each quiz are: 100   100   100   97   96   
Average Scores for each quiz are: 53.2   54.8   65.3   66.1   53.9   


Stud	Q1	Q2	Q3	Q4	Q5
1234	52	7	100	78	34

Lowest Scores for each quiz are: 0   7   0   0   10   
Highest Scores for each quiz are: 100   100   100   97   96   
Average Scores for each quiz are: 53.2   54.8   65.3   66.1   53.9   

*/