package driver;
import model.*;
import util.FileIO;

public class Driver1 {

	public static void main(String[] args) {
		Student lab2 [] = new Student[40];
		FileIO a1 = new FileIO ();
		
		a1.readFile("StudentRecordError.txt", lab2);
		
		System.out.printf("\nStud\tQ1\tQ2\tQ3\tQ4\tQ5\n");
		for (int i = 0; i < lab2.length; i++) {
			if (lab2[i] == null) {
				break;
			}
			else {
				lab2[i].print();
			}
		}
	}

}

//SAMPLE RUN USING StudentRecordError.txt
/*
Quiz 5 score was missing on Student ID 6999, assuming score to 0
got here --> fixProblemReadFromConsole

Stud	Q1	Q2	Q3	Q4	Q5
1234	52	7	100	78	34
2134	90	36	90	77	30
3124	100	45	20	90	70
4532	11	17	81	32	77
5678	20	12	45	78	34
6134	34	80	55	78	45
7874	60	100	56	78	78
8026	70	10	66	78	56
9893	34	9	77	78	20
1947	45	40	88	78	55
2877	55	50	99	78	80
3189	22	70	100	78	77
4602	89	50	91	78	60
5405	11	11	0	78	10
6999	0	98	89	78	0
4321	99	89	77	97	88
3341	66	56	45	63	30
9014	12	22	11	0	23
2002	81	87	83	77	89
3041	32	45	33	55	45
2222	69	72	55	73	62
6723	88	95	88	79	92
7777	99	87	66	89	73
2345	44	33	45	23	55
3333	23	45	66	33	12
5922	67	58	48	77	82
3045	34	33	55	50	21
5960	40	23	70	44	33
4444	52	67	70	47	88
9834	99	97	92	89	96
6390	33	66	69	18	24
1210	67	68	60	77	59
2048	100	89	94	92	88
5100	50	55	60	45	72
6756	46	77	65	59	67
1302	30	52	33	46	18
258		77	56	89	68	77
124		43	42	56	66	70
5698	50	68	89	69	19
3377	33	77	37	73	27
*/