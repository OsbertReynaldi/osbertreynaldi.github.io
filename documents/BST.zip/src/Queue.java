/**
 * Queue class - singly-linked list version
 * @author Osbert Sudjana
 * @author Sharon Utomo
 * CIS 22C, Lab 4
 */

import java.util.NoSuchElementException;

public class Queue<T>{
	private class Node {
		private T data;
		private Node next;

		public Node(T data) {
			this.data = data;
			this.next = null;
		}
	}

	private Node front;
	private Node end;
	private int size;

	/**
	 * Default constructor for the Queue class
	 */
	public Queue() {
		front = null;
		end = null;
		size = 0;
	}

	/**
	 * Converts an array into a Queue
	 * 
	 * @param array the array to copy into the Queue
	 */
	public Queue(T[] array) {
		if (array == null) {
			front = null;
			end = null;
			size = 0;
		} else {
			for (int i = 0; i < array.length; i++) {
				enqueue(array[i]);
			}
		}
	}

	/**
	 * Copy constructor for the Queue class Makes a deep copy of the parameter
	 * 
	 * @param aQueue another Queue to copy
	 */
	public Queue(Queue<T> aQueue) {
		if (aQueue == null) {
			return;
		}
		if (aQueue.size == 0) {
			size = 0;
			front = null;
			end = null;
		} else {
			Node temp = aQueue.front;
			while (temp != null) {
				this.enqueue(temp.data);
				temp = temp.next;
			}
		}
	}

	/**** ACCESSORS ****/

	public T getFront() throws NoSuchElementException {
		if (isEmpty()) {
			throw new NoSuchElementException("getFront(): Queue is empty. No Front Element");
		}
		return front.data;
	}

	public int getSize() {
		return size;
	}

	public boolean isEmpty() {
		return size == 0;
	}

	/**** MUTATORS ****/

	public void enqueue(T data) {
		Node N = new Node(data);
		if (isEmpty()) { // edge case
			front = N;
			end = N;
		} else {// general case
			end.next = N;
			end = N;
		}
		size++;

	}

	public void dequeue() throws NoSuchElementException {
		if (isEmpty()) {
			throw new NoSuchElementException("dequeue(): Queue is empty. No node to dequeue");
		} else if (size == 1) {
			front = null;
			end = null;
		} else {
			front = front.next;
		}
		size--;
	}

	/**** ADDITONAL OPERATIONS ****/

	/**
	 * Returns the values stored in the Queue as a String, separated by a blank
	 * space with a new line character at the end
	 * 
	 * @return a String of Queue values
	 */
	@Override
	public String toString() {
		StringBuilder result = new StringBuilder();
		Node temp = front;
		while (temp != null) {
			result.append(temp.data + " ");
			temp = temp.next;
		}
		return result.toString() + "\n";
	}

	/**
	 * Determines whether two Queues contain the same values in the same order
	 * 
	 * @param o the Object to compare to this
	 * @return whether o and this are equal
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean equals(Object o) {
		if (o == this) {
			return true;
		} else if (!(o instanceof Queue)) {
			return false;
		} else {
			Queue<T> Q = (Queue<T>) o;
			if (this.size != Q.size) {
				return false;
			} else {
				Node temp1 = this.front;
				Node temp2 = Q.front;
				while (temp1 != null) {
					if (!(temp1.data.equals(temp2.data))) {
						return false;
					}
					temp1 = temp1.next;
					temp2 = temp2.next;
				}
			}
			return true;
		}
	}

	public String reverseQueue() {
		if (size == 0) {
			return "\n";
		} else {
			return reverseQueue(front) + " \n";
		}
	}

	/** RECURSIVE HELPER METHODS */

	/**
	 * Recursively (no loops) creates a String where the data is in reverse order
	 * 
	 * @param n the current node
	 */
	private String reverseQueue(Node n) {
		if (n == this.end) {
			return this.end.data + "";
		} else {
			return reverseQueue(n.next) + " " + n.data;
		}
	}

}
