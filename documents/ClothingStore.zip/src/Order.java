/**
 * @author ShriaRajbhandari
 * Final Project CIS 22C
 */
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class Order {
	private int orderId;
	private Customer customer;
	private String date;
	private LinkedList<Clothes> orderContents; 
	private int shippingSpeed; // 3: Overnight,2: Rush,1: Standard
	private int priority;// 3****, 2****, 1****
	
	public Order() {
		this.orderId = 0;
		this.date = "";
		this.customer = null;
		this.orderContents = null;
		this.shippingSpeed = 0;
	}

	public Order(int orderId, String date, Customer customer, LinkedList<Clothes> list, int shippingSpeed) throws ParseException {
		this.orderId = orderId;
		this.date = date;
		this.customer = customer;
		this.orderContents = list;
		this.shippingSpeed = shippingSpeed;
		makePriority();
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customerName) {
		this.customer = customerName;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String newDate) {
		this.date = newDate;
	}

	public int getShippingSpeed() {
		return shippingSpeed;
	}

	public void setShippingSpeed(int newSpeed) {
		this.shippingSpeed = newSpeed;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int newPriority) {
		this.priority = newPriority;
	}

	public LinkedList<Clothes> getOrderContents() {
		return orderContents;
	}

	public void setOrderContents(LinkedList<Clothes> orderContents) {
		this.orderContents = orderContents;
	}

	private void makePriority() throws ParseException {
		Date today = new Date();

		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH);
		Date firstDate = sdf.parse(date);

		long diff = today.getTime() - firstDate.getTime();
		TimeUnit time = TimeUnit.DAYS;
		long difference = time.convert(diff, TimeUnit.MILLISECONDS);

		int numDigits = 0;
		while (difference != 0) {
			difference /= 10;
			++numDigits;
		}

		setPriority((int) (shippingSpeed * 10 ^ numDigits + difference));

	}

	@Override
	public String toString() {
		StringBuilder result = new StringBuilder();
		result.append("\n" + orderId + "\n" + customer.getFirstName() + "\n" + customer.getLastName() 
					+ "\n" + date + "\n");
		
		orderContents.positionIterator();
		for(int i = 0; i < orderContents.getLength(); i++) {
			if(i == (orderContents.getLength()-1)) {
				result.append(orderContents.getIterator().getProductName() + " "
						+ orderContents.getIterator().getSize());
			}
			else {
			result.append(orderContents.getIterator().getProductName() + " "
					+ orderContents.getIterator().getSize() + ",");
			}
			orderContents.advanceIterator();
		}
		result.append("\n");
		if (shippingSpeed == 1) {
			result.append("Standard");
		}
		else if (shippingSpeed == 2) {
			result.append("Rush");
		}
		else if (shippingSpeed == 3) {
			result.append("Overnight");
		}
		
		return result.toString() + "\n";
	}

}

class PriorityComparator implements Comparator<Order> {
	@Override
	public int compare(Order order1, Order order2) {
		return Integer.compare(order1.getPriority(), order2.getPriority());
	}
}

class NameComparator implements Comparator<Order> {
	@Override
	public int compare(Order order1, Order order2) {
		return order1.getCustomer().getFirstName().compareTo(order2.getCustomer().getFirstName());
	}
}

class OrderIdComparator implements Comparator<Order> {
	@Override
	public int compare(Order order1, Order order2) {
		return Integer.compare(order1.getOrderId(), order2.getOrderId());
	}
}

