/**
 * @author Bryan Quach
 * @author Dylan Le
 * Final Project CIS 22C
 */

import java.util.Comparator;

public class ClothesPrimaryCompare implements Comparator<Clothes> {

        @Override
        public int compare(Clothes o1, Clothes o2) {
            return o1.getProductName().compareTo(o2.getProductName());
        }

    };