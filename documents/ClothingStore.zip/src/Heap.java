
/**
 * @author ShriaRajbhandari
 * Final Project CIS 22C
 */

import java.util.Comparator;
import java.util.ArrayList;
import java.util.Collections;

public class Heap<T> {

	private int heapSize;
	private ArrayList<T> heap;

	/**
	 * Constructors/
	 * 
	 * /** Constructor for the Heap class
	 * 
	 * @param data an unordered ArrayList Calls buildHeap
	 */
	public Heap(ArrayList<T> data, Comparator<T> comparator) {
		if (data == null) {
			return;
		}
		if (data.isEmpty()) {
			heapSize = 0;
			heap = new ArrayList<T>();
		} else {
			heap = new ArrayList<T>(data);
			heapSize = heap.size();
			buildHeap(comparator);
		}
	}

	/** Mutators */

	/**
	 * Converts an ArrayList into a valid max heap. Called by constructor Calls
	 * helper method heapify
	 */
	public void buildHeap(Comparator<T> comparator) {
		int n = heapSize;
		for (int i = n / 2 - 1; i >= 0; i--) {
			heapify(i, comparator);
		}
	}

	/**
	 * helper method to buildHeap, remove, and sort bubbles an element down to its
	 * proper location within the heap
	 * 
	 * @precondition index >= 0 and index < heapSize
	 * @param index an index in the heap
	 * @throws IndexOutOfBoundsException when the precondition is violated
	 * 
	 */
	private void heapify(int index, Comparator<T> comparator) throws IndexOutOfBoundsException {
		if (index < 0 || index >= heapSize) {
			throw new IndexOutOfBoundsException("heapify(): Index out of Bound!");
		} else {
			int max_index = index;
			int l = get_left(index);
			int r = get_right(index);
			if (l < heapSize && comparator.compare(getElement(l), getElement(max_index)) > 0) {
				max_index = l;
			}
			if (r < heapSize && comparator.compare(getElement(r), getElement(max_index)) > 0) {
				max_index = r;
			}
			if (index != max_index) {
				swap(max_index, index);
				heapify(max_index, comparator);
			}
		}
	}

	/**
	 * Inserts the given data into heap Calls helper method heapIncreaseKey
	 * 
	 * @param key the data to insert
	 */
	public void insert(T key, Comparator<T> comparator) {
		heapSize++;
		heap.add(key);
		heapIncreaseKey(heapSize - 1, key, comparator);
	}

	/**
	 * Helper method for insert. Bubbles an element up to its proper location
	 * 
	 * @param index the current index of the key where we want to insert it
	 * @param key   the data to insert
	 * @precondition index >= 0 and index < heapSize throws IndexOutOfBoundException
	 *               when the precondition is violated
	 */
	private void heapIncreaseKey(int index, T key, Comparator<T> comparator) throws IndexOutOfBoundsException {
		if (index < 0 || index >= heapSize) {
			throw new IndexOutOfBoundsException("heapIncreaseKey(): Index out of Bound!");
		}
		heap.set(index, key);
		while (index > 0 && comparator.compare(getElement(index), getElement(getParent(index))) > 0) {
			swap(getParent(index), index);
			index = getParent(index);
		}
	}

	/**
	 * removes the element at the specified index Calls helper method heapify
	 * 
	 * @param index the index of the element to remove
	 * @precondition index >= 0 and index < heapSize
	 * @throws IndexOutOfBoundsException when the precondition is violated
	 */
	public void remove(int index, Comparator<T> comparator) throws IndexOutOfBoundsException {
		if (index < 0 || index >= heapSize) {
			throw new IndexOutOfBoundsException("remove(): Index out of Bound!");
		}
		T temp = heap.get(index);
		heap.set(index, heap.get(heapSize - 1));
		heap.set(heapSize - 1, temp);
		// Heap size --
		heapSize--;
		heapify(0, comparator);
	}

	/** Accessors */

	/**
	 * returns the maximum element (highest priority)
	 * 
	 * @return the max value
	 */
	public T getMax() {
		return heap.get(0);
	}

	/**
	 * returns the location (index) of the parent of the element stored at index
	 * 
	 * @param index the current index
	 * @return the index of the parent
	 * @precondition index >= 0 and index < heapSize
	 * @throws IndexOutOfBoundsException when the precondition is violated
	 */
	public int getParent(int index) throws IndexOutOfBoundsException {
		if (index < 0 || index >= heapSize) {
			throw new IndexOutOfBoundsException("getParent(): Index out of Bound!");
		}
		return (int) Math.floor(index / 2);
	}

	/**
	 * returns the location (index) of the left child of the element stored at index
	 * 
	 * @param index the current index
	 * @return the index of the left child
	 * @precondition index >= 0 and index < heapSize
	 * @throws IndexOutOfBoundsException when the precondition is violated
	 */
	public int get_left(int index) throws IndexOutOfBoundsException {
		if (index < 0 || index >= heapSize) {
			throw new IndexOutOfBoundsException("get_left(): Index out of Bound!");
		}
		return (int) Math.floor(index * 2);
	}

	/**
	 * returns the location (index) of the right child of the element stored at
	 * index
	 * 
	 * @param index the current index
	 * @return the index of the right child
	 * @precondition index >= 0 and index < heapSize
	 * @throws IndexOutOfBoundsException when the precondition is violated
	 */
	public int get_right(int index) throws IndexOutOfBoundsException {
		if (index < 0 || index >= heapSize) {
			throw new IndexOutOfBoundsException("get_right(): Index out of Bound!");
		}
		return (int) Math.floor((2 * index) + 1);

	}

	/**
	 * returns the heap size (current number of elements)
	 * 
	 * @return the size of the heap
	 */
	public int getHeapSize() {
		return heapSize;
	}

	/**
	 * Gets the element at the specified index
	 * 
	 * @param index at which to access
	 * @return the element at index
	 * @precondition index >= 0 and index < heapSize
	 * @throws IndexOutOfBoundsException when the precondition is violated
	 */
	public T getElement(int index) throws IndexOutOfBoundsException {
		if (index < 0 || index >= heapSize) {
			throw new IndexOutOfBoundsException("getElement(): Index out of Bound!");
		}
		return heap.get(index);
	}

	/** Additional Operations */

	/**
	 * Creates a String of all elements in the heap
	 */
	@Override
	public String toString() {
		StringBuilder result = new StringBuilder();
		if (!heap.isEmpty()) {
			for (int i = 0; i < heapSize; i++) {
				result.append(getElement(i).toString());
			}
		}
		return result.toString();
	}

	/**
	 * Swaps the elements of index1 and index2
	 * 
	 * @param index1 the index to swap with index2
	 * @param index2 the index to swap with index1
	 * @precondition index >= 0 and index < heapSize
	 * @throws IndexOutOfBoundsException when the precondition is violated
	 */
	public void swap(int index1, int index2) throws IndexOutOfBoundsException {
		if (index1 < 0 || index1 >= heapSize || index2 < 0 || index2 >= heapSize) {
			throw new IndexOutOfBoundsException("swap(): Index out of Bound!");
		}
		T temp;
		temp = getElement(index1);
		heap.set(index1, getElement(index2));
		heap.set(index2, temp);
	}

	/**
	 * Uses the heap sort algorithm to sort the heap into ascending order Calls
	 * helper method heapify
	 * 
	 * @return an ArrayList of sorted elements
	 * @postcondition heap remains a valid heap
	 */
	public ArrayList<T> sort(Comparator<T> comparator) {
		ArrayList<T> sortedArray = new ArrayList<T>();
		ArrayList<T> originalHeap = new ArrayList<T>();
		for (int i = 0; i < heapSize; i++) {
			originalHeap.add(heap.get(i));
		}
		int n = heapSize;
		for (int i = n - 1; i >= 1; i--) {
			// Swap
			T temp = heap.get(0);
			heap.set(0, heap.get(i));
			heap.set(i, temp);
			sortedArray.add(temp);
			heap.remove(i);
			// Heap size --
			heapSize--;
			heapify(0, comparator);
		}
		sortedArray.add(heap.get(0));
		Collections.reverse(sortedArray);
		heap.remove(0);
		heapSize = n;
		for (int i = 0; i < n; i++) {
			heap.add(originalHeap.get(i));
		}
		return sortedArray;
	}

}