/**
 * BST.java
 * @author Bryan Quach
 * @author Dylan Le
 * CIS 22C Lab 4
 */


import java.util.ArrayList;
import java.util.Comparator;
import java.util.NoSuchElementException;

public class BST<T> {
	
    private class Node {
        private T data;
        private Node left;
        private Node right;
        
        public Node(T data) {
            this.data = data;
            left = null;
            right = null;
        }
    }
    
    
    
	/*
	 * 
	 * public static class ComparePrimary implements Comparator<Clothes> {
	 * 
	 * @Override public int compare(Clothes o1, Clothes o2) { return
	 * o1.getProductName().compareTo(o2.getProductName()); }
	 * 
	 * };
	 * 
	 * public static class CompareSecondary implements Comparator<Clothes> {
	 * 
	 * @Override public int compare(Clothes o1, Clothes o2) { return
	 * o1.getSize().compareTo(o2.getSize()); }
	 * 
	 * };
	 */
    
    private Node root;
    
    /***CONSTRUCTORS***/
    
    /**
     * Default constructor for BST
     * sets root to null
     */
    public BST() {
    	root = null;
    }
   
    /**
     * Copy constructor for BST
     * @param bst the BST to make
     * a copy of 
     */
    public BST(BST<T> bst, Comparator<T> com) {
       if (bst == null) {
    	   return;
       } else if (bst.isEmpty()) {
    	   this.root = null;
       } else {
    	   copyHelper(bst.root, com);
       }
    }
    
    /**
     * Helper method for copy constructor
     * @param node the node containing
     * data to copy
     */
    private void copyHelper(Node node, Comparator<T> com) {
       if(node==null) {
    	   return;
       } else {
    	   insert(node.data, com);
    	   copyHelper(node.left, com);
    	   copyHelper(node.right, com);
       }
    }
    
    /***ACCESSORS***/
    
    /**
     * Returns the data stored in the root
     * @precondition !isEmpty()
     * @return the data stored in the root
     * @throws NoSuchElementException when
     * precondition is violated
     */
    public T getRoot() throws NoSuchElementException {
    	if(isEmpty()) {
    		throw new NoSuchElementException("getRoot: Queue is empty.");
    	}
        return root.data;
    }
    
    /**
     * Determines whether the tree is empty
     * @return whether the tree is empty
     */
    public boolean isEmpty() {
       return root == null;
    }
    
    /**
     * Returns the current size of the 
     * tree (number of nodes)
     * @return the size of the tree
     */
    public int getSize() { 
    	return getSize(root);
    }
    
    /**
     * Helper method for the getSize method
     * @param node the current node to count
     * @return the size of the tree
     */
    private int getSize(Node node) {
    	if (node == null) {
    		return 0;
    	} else {
    		return (getSize(node.left) + getSize(node.right) + 1);
    	}
    }
    
    /**
     * Returns the height of tree by
     * counting edges.
     * @return the height of the tree
     */
    public int getHeight() {
        return getHeight(root);
    }
    
    /**
     * Helper method for getHeight method
     * @param node the current
     * node whose height to count
     * @return the height of the tree
     */
    private int getHeight(Node node) {
		int lefth = 0;
		int righth = 0;
		if (node == null) {
			return -1;
		} else {
			lefth = getHeight(node.left);
			righth = getHeight(node.right);
			if (lefth > righth) {
				return lefth + 1;
			} else {
				return righth + 1;
			}
		}
    }
    
    /**
     * Returns the smallest value in the tree
     * @precondition !isEmpty()
     * @return the smallest value in the tree
     * @throws NoSuchElementException when the
     * precondition is violated
     */
    public T findMin() throws NoSuchElementException{
    	if(isEmpty()) {
    		throw new NoSuchElementException("findMin: BST is empty");
    	}
        return findMin(root);
    }
    
    /**
     * Helper method to findMin method
     * @param node the current node to check
     * if it is the smallest
     * @return the smallest value in the tree
     */
    private T findMin(Node node) {
    	if(node.left != null) {
    		return findMin(node.left);
    	} else {
            return node.data;
    	}
    }
    
    /**
     * Returns the largest value in the tree
     * @precondition !isEmpty()
     * @return the largest value in the tree
     * @throws NoSuchElementException when the
     * precondition is violated
     */
    public T findMax() throws NoSuchElementException{
    	if(isEmpty()) {
    		throw new NoSuchElementException("findMax: BST is empty");
    	}
        return findMax(root);
    }
    
    /**
     * Helper method to findMax method
     * @param node the current node to check
     * if it is the largest
     * @return the largest value in the tree
     */
    private T findMax(Node node) {
    	if(node.right != null) {
    		return findMax(node.right);
    	} else {
            return node.data;
    	}
    }
    
    /***MUTATORS***/
    
    /**
     * Inserts a new node in the tree
     * @param data the data to insert
     */
    public void insert(T data,Comparator<T> com) {
    	if (root == null) {
    		root = new Node(data);
    	} else {
            insert(data, root,com);
        }
    }
    
    /**
     * Helper method to insert
     * Inserts a new value in the tree
     * @param data the data to insert
     * @param node the current node in the
     * search for the correct location
     * in which to insert
     */
    private void insert(T data, Node node,Comparator<T> com) {
    	if(com.compare(data, node.data) <= 0) {
    		if(node.left == null) {
    			node.left = new Node(data);
    		} else {
    			insert(data,node.left,com);
    		}
    	} else {
    		if (node.right == null) {
    			node.right = new Node(data);
    		} else {
    			insert(data, node.right,com);
    		}
    	}
    }
    
    /**
     * Removes a value from the BST
     * @param data the value to remove
     * @precondition !isEmpty()
     * @throws IllegalStateException when BST is empty
     */
    public void remove(T data,Comparator<T> com) throws IllegalStateException {
      if (isEmpty()) {
    	  throw new IllegalStateException("remove: BST is empty!");
      } else {
    	  root = remove(data, root,com);
      }
    }
    
    /**
     * Helper method to the remove method
     * @param data the data to remove
     * @param node the current node
     * @return an updated reference variable
     */
    private Node remove(T data, Node node,Comparator<T> com) {
		if (node == null) {
			return node;
		} else if (com.compare(data, node.data) < 0) {
			node.left = remove(data, node.left,com);
		} else if (com.compare(data, node.data) > 0) {
			node.right = remove(data, node.right,com);
		} else {
			if ((node.left == null && node.right == null)) {
				node = null;
			} else if (node.left != null && node.right == null) {
				node = node.left;
			} else if (node.left == null && node.right != null) {
				node = node.right;
			} else {
				node.data = findMin(node.right);
				node.right = remove(findMin(node.right), node.right,com);
			}
		}
		return node;


    }
    
        
    /***ADDITIONAL OPERATIONS***/
    
    /**
     * Searches for a specified value
     * in the tree
     * @param data the value to search for
     * @return whether the value is stored
     * in the tree
     */
    public T search(T data,Comparator<T> com) {
    	if(root == null) {
            return null;
        } else {
            return search(data,root, com);
        }
    }
    
    /**
     * Helper method for the search method
     * @param data the data to search for
     * @param node the current node to check
     * @return whether the data is stored
     * in the tree
     */
    private T search(T data, Node node, Comparator<T> com) {
    	 if (node == null) {
    		 return null;
    	 } else if (com.compare(data,node.data) == 0) {
    		 return node.data;
    	 } else if (com.compare(data,node.data) < 0) {
    		 return search(data,node.left,com);
    	 } else {
    		 return search(data,node.right,com);
    	 }
    }
   
    /**
     * Returns a String containing the data
     * in post order
     * @return a String of data in post order
     */
    public String preOrderString() {
    	StringBuilder pre = new StringBuilder();
    	preOrderString(root,pre);
        return pre.toString() + "\n";
    }
    
    /**
     * Helper method to preOrderString
     * Inserts the data in pre order into a String
     * @param node the current Node
     * @param preOrder a String containing the data
     */
    private void preOrderString(Node node, StringBuilder preOrder) {
    	if (node == null) {
       		return;
    	} else {
       		preOrder.append(node.data);
    		preOrderString(node.left, preOrder);
       		preOrderString(node.right, preOrder);
    	}
    }
    
    /**
     * Returns a String containing the data
     * in order
     * @return a String of data in order
     */
    public String inOrderString() {
    	StringBuilder in = new StringBuilder();
    	inOrderString(root,in);
        return in.toString() + "\n";
    }
    
    /**
     * Helper method to inOrderString
     * Inserts the data in order into a String
     * @param node the current Node
     * @param inOrder a String containing the data
     */
    private void inOrderString(Node node, StringBuilder inOrder) {
    	if (node == null) {
       		return;
    	} else {
    		inOrderString(node.left, inOrder);
       		
       		inOrder.append(node.data);
       		inOrderString(node.right, inOrder);
    	}
    }
    
    /**
     * Returns a String containing the data
     * in post order
     * @return a String of data in post order
     */
    public String postOrderString() {
    	StringBuilder post = new StringBuilder();
    	postOrderString(root,post);
        return post.toString() + "\n";
    }
    
    /**
     * Helper method to postOrderString
     * Inserts the data in post order into a String
     * @param node the current Node
     * @param postOrder a String containing the data
     */
    private void postOrderString(Node node, StringBuilder postOrder) {
    	if (node == null) {
       		return;
    	} else {
    		postOrderString(node.left, postOrder);
       		postOrderString(node.right, postOrder);
       		postOrder.append(node.data);
    	}
    }

 

   /**
     * Creates a String that is a depth order
     * traversal of the data in the tree
     * @return the level order traversal as a String
     */
    public String depthOrderString() {
    	if(isEmpty()) {
    		return "\n";
    	}
    	StringBuilder depth = new StringBuilder();
    	Queue<Node> q = new Queue<Node>();
    	depthOrderString(q, depth);
        return depth.toString() + "\n";
    }
    
    /**
     * Helper method to depthOrderString
     * Inserts the data in depth order into a String starting from 0
     * @param q the Queue in which to store the data
     * @param depthOrder a StringBuilder containing the data
     */
    private void depthOrderString(Queue<Node> q, StringBuilder depthOrder) {
    	q.enqueue(root);
        while (!q.isEmpty()) {
        	Node node = q.getFront();
        	depthOrder.append(node.data + " ");
            if (node.left != null) {
                q.enqueue(node.left);  
            } 
            if (node.right != null) {
                q.enqueue(node.right);
                
            } 
            q.dequeue();
        }
    }
    
    
    /**
     * Creates a BST of minimal height given an array of values
     * @param array the list of values to insert
     * @precondition array must be sorted in ascending order
     * @throws IllegalArgumentException when the array is
     * unsorted
     */
    public BST(T[] array, Comparator<T> com) throws IllegalArgumentException {
    	if (array == null) {
    		return;
    	} else if(array.length==0) {
    		root = null; 
    	}
    	if (!isSorted(array,com)) {
    		throw new IllegalArgumentException("BST: Array is not sorted!");
    	} else{
    		arrayHelper(array, 0, array.length-1,com);
    	}
    }
    
    private void arrayHelper(T[] array, int low, int high, Comparator<T> com) { 
    	if (high < low) {
            return;
        }
        int mid = low + (high - low) / 2; //midpoint formula
        insert(array[mid], com);
        arrayHelper(array, low, mid-1, com);
        arrayHelper(array, mid+1, high, com);
    }
    
    private boolean isSorted(T[] array,Comparator<T> com) {
    	for (int i=0; i<array.length-1; i++) {
    		if(com.compare(array[i], array[i+1]) > 0) {
    			return false;
    		} 
    	}
    	return true;
    }

}


