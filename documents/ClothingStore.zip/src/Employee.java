/**
 * @author Osbert Sudjana
 * Final Project CIS 22C
 */
public class Employee extends User{

	private boolean isManager;
	
	public Employee() {
		userName = "";
		password = "";
		isManager = false;
	}
	
	public Employee(String newUserName, String newPassword, String firstName, String lastName, boolean manager) {
		super(newUserName, newPassword, firstName, lastName);
		isManager = manager;
	}
	
	public boolean isManager() {
		return isManager;
	}

	public void setManager(boolean isManager) {
		this.isManager = isManager;
	}
	
	@Override public int hashCode() {
        String key = userName + password; //this will store the "key" for this class
        int sum = 0;
        for (int i = 0; i < key.length(); i++) {
            sum += (int) key.charAt(i);
        }
        return sum;
    }
    
    @Override public boolean equals(Object o) {
        if(this == o) {
            return true;
        } else if (!(o instanceof Employee)) {
            return false;
        } else {
            Employee s = (Employee) o;
            return this.password.equals(s.password) && s.userName.equals(this.userName);
        }
    }
    
    public boolean compareTo(Employee s) {
        if(this.equals(s)) {
            return true;
        } else if (this.password.equals(s.password)) {
            return this.userName.equals(s.userName);
        } else if (this.userName.equals(s.userName)){
            return this.password.equals(s.password);
        }
        
        return false;
    }
	
	public String toString() {
		return ("Username: " + userName + "\n Password: " + password + "\n");
	}
}
