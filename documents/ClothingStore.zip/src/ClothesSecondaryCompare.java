/**
 * @author Bryan Quach
 * @author Dylan Le
 * Final Project CIS 22C
 */
import java.util.Comparator;

public class ClothesSecondaryCompare implements Comparator<Clothes> {

        @Override
        public int compare(Clothes o1, Clothes o2) {
        	return Double.compare(o1.getPrice(), o2.getPrice());
        }

    };