/**
 * @author Osbert Sudjana
 * @author Shria Rajbhandari
 * @author Bryan Quach
 * @author Dylan Le
 * @author Sharon Utomo
 * Final Project CIS 22C
 */

public class Clothes{
	private String productName; //primary key
    private String size; 
    private String color;
    private String material;
    private int numInStock;
    private String madeIn; 
    private double price;  //secondary key
    
    public Clothes() {
    	productName = "";
    	size = "";
    	material = "";
    	numInStock = 0;
    	madeIn = "";
    	price = 0.0;
    }
    
    public Clothes(String productName, String size, String color, String material, int numInStock, String madeIn, double price) {
		super();
		this.productName = productName;
		this.size = size;
		this.color = color;
		this.material = material;
		this.numInStock = numInStock;
		this.madeIn = madeIn;
		this.price = price;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}

	public int getNumInStock() {
		return numInStock;
	}

	public void setNumInStock(int numInStock) {
		this.numInStock = numInStock;
	}

	public String getMadeIn() {
		return madeIn;
	}

	public void setMadeIn(String madeIn) {
		this.madeIn = madeIn;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return (productName + "\n" + size + "\n" + color + "\n" + material + "\n" + numInStock + "\n" + madeIn + "\n" + price + "\n\n");
	}
    
    
}


