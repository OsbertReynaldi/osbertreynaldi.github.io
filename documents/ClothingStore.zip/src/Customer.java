/**
 * @author Osbert Sudjana
 * Final Project CIS 22C
 */

public class Customer extends User{ 

	private String address;

	private String city;
	
	private String state;

	private String zip; 

	private LinkedList<Order> shippedOrders; 

	private LinkedList<Order> unshippedOrders;
	
	public Customer() {
		super();
		this.address = "";
		this.city = "";
		this.state = "";
		this.zip = "";
		this.shippedOrders = new LinkedList<Order>();
		this.unshippedOrders = new LinkedList<Order>();
	}
	
	public Customer(String newUserName, String newPassword, String firstName, String lastName, String address, String city, String state, String zip) {
		super(newUserName, newPassword, firstName, lastName);
		this.address = address;
		this.city = city;
		this.state = state;
		this.zip = zip;
		this.shippedOrders = new LinkedList<Order>();
		this.unshippedOrders = new LinkedList<Order>();
	}
	
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public LinkedList<Order> getShippedOrders() {
		return shippedOrders;
	}

	public void setShippedOrders(LinkedList<Order> shippedOrders) {
		this.shippedOrders = shippedOrders;
	}

	public LinkedList<Order> getUnshippedOrders() {
		return unshippedOrders;
	}

	public void setUnshippedOrders(LinkedList<Order> unshippedOrders) {
		this.unshippedOrders = unshippedOrders;
	}
	
	@Override public int hashCode() {
        String key = userName + password; //this will store the "key" for this class
        int sum = 0;
        for (int i = 0; i < key.length(); i++) {
            sum += (int) key.charAt(i);
        }
        return sum;
    }
    
    @Override public boolean equals(Object o) {
        if(this == o) {
            return true;
        } else if (!(o instanceof Customer)) {
            return false;
        } else {
            Customer s = (Customer) o;
            return (this.password.equals(s.password) && s.userName.equals(this.userName)) || (this.firstName.equals(s.firstName) && s.lastName.equals(this.lastName));
        }
    }
    
    public boolean compareTo(Customer s) {
        if(this.equals(s)) {
            return true;
        } else if (this.password.equals(s.password)) {
            return this.userName.equals(s.userName);
        } else if (this.userName.equals(s.userName)){
            return this.password.equals(s.password);
        }
        
        return false;
    }
	
	public String toString() {
		return (this.getUserName() + "\n" + this.getPassword()
		+ "\n" + this.getFirstName() + "\n" + this.getLastName()
		+ "\n" + this.getAddress() + "\n" + this.getCity()
		+ "\n" + this.getState() + "\n" + this.getZip() + "\n");
	}
}
