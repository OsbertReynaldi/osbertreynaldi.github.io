/**
 * @author Osbert Sudjana
 * @author Shria Rajbhandari
 * @author Bryan Quach
 * @author Dylan Le
 * @author Sharon Utomo
 * Final Project CIS 22C
 */

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.Random;

public class Driver {
	
	public static void main(String[] args) throws ParseException {

		PriorityComparator PriorityComparator = new PriorityComparator(); // comparison by priority (shipping, date and
																			// time)
		NameComparator NameComparator = new NameComparator();// comparison by alphabetical order of the name
		OrderIdComparator OrderIdComparator = new OrderIdComparator(); // comparison by orderId
		ClothesPrimaryCompare ClothesPrimaryCompare = new ClothesPrimaryCompare();
		ClothesSecondaryCompare ClothesSecondaryCompare = new ClothesSecondaryCompare();

		Scanner input = new Scanner(System.in);
		int loginType;
		String temp;

		System.out.println("Welcome to the CIS 22C Clothing store\n");
		System.out.println("Enter 1 to login as a Customer \nEnter 2 to login as an Employee\n");

		HashTable<Customer> ht = new HashTable<Customer>(25);
		ArrayList<Order> unshippedOrders = new ArrayList<Order>();
		ArrayList<Order> shippedOrders = new ArrayList<Order>();
		Heap<Order> unshippedHeap = new Heap<Order>(unshippedOrders, PriorityComparator);
		Heap<Order> shippedHeap = new Heap<Order>(shippedOrders, PriorityComparator);
		BST<Clothes> clothes = new BST<Clothes>();
		BST<Clothes> clothesSecondary = new BST<Clothes>();

		try {
			FileInputStream fstream = new FileInputStream("Customer.txt");
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine, username = null, password = null, firstName = null, lastName = null, address = null,
					city = null, state = null, zip = null;
			int counter = 1;
			while ((strLine = br.readLine()) != null || counter == 9) {
				// if(strLine.trim().length() > 0) {
				if (counter == 1) {
					username = strLine;
				}
				if (counter == 2) {
					password = strLine;
				}
				if (counter == 3) {
					firstName = strLine;
				}
				if (counter == 4) {
					lastName = strLine;
				}
				if (counter == 5) {
					address = strLine;
				}
				if (counter == 6) {
					city = strLine;
				}
				if (counter == 7) {
					state = strLine;
				}
				if (counter == 8) {
					zip = strLine;
				}
				if (counter == 9) {
					Customer customer = new Customer(username, password, firstName, lastName, address, city, state,
							zip);
					ht.add(customer);
					counter = 0;
				}
				counter++;
				// }
			}
			in.close();
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
		}

		// BUILD BST OF CLOTHES THROUGH CLOTHES.TXT
		try {
			String name = "", size = "", color = "", material = "", madeIn = "";
			int numInStock = 0;
			double price = 0.0;
			FileInputStream fstream = new FileInputStream("Clothes.txt");
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			int counter = 1;
			while ((strLine = br.readLine()) != null || counter == 8) {
				// if(strLine.trim().length() > 0) {
				if (counter == 1) {
					name = strLine;
				}
				if (counter == 2) {
					size = strLine;
				}
				if (counter == 3) {
					color = strLine;
				}
				if (counter == 4) {
					material = strLine;
				}
				if (counter == 5) {
					numInStock = Integer.parseInt(strLine);
				}
				if (counter == 6) {
					madeIn = strLine;
				}
				if (counter == 7) {
					price = Double.parseDouble(strLine);
				}
				if (counter == 8) {
					Clothes cl1 = new Clothes(name, size, color, material, numInStock, madeIn, price);
					clothes.insert(cl1, ClothesPrimaryCompare);
					counter = 0;
				}
				counter++;
				// }
			}
			in.close();
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
		}

		try {
			String name = "", size = "", color = "", material = "", madeIn = "";
			int numInStock = 0;
			double price = 0.0;
			FileInputStream fstream = new FileInputStream("Clothes.txt");
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			int counter = 1;
			while ((strLine = br.readLine()) != null || counter == 8) {
				// if(strLine.trim().length() > 0) {
				if (counter == 1) {
					name = strLine;
				}
				if (counter == 2) {
					size = strLine;
				}
				if (counter == 3) {
					color = strLine;
				}
				if (counter == 4) {
					material = strLine;
				}
				if (counter == 5) {
					numInStock = Integer.parseInt(strLine);
				}
				if (counter == 6) {
					madeIn = strLine;
				}
				if (counter == 7) {
					price = Double.parseDouble(strLine);
				}
				if (counter == 8) {
					Clothes cl1 = new Clothes(name, size, color, material, numInStock, madeIn, price);
					clothesSecondary.insert(cl1, ClothesSecondaryCompare);
					counter = 0;
				}
				counter++;
				// }
			}
			in.close();
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
		}

		try {
			FileInputStream fstream = new FileInputStream("UnshippedOrders.txt");
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine, firstName = null, lastName = null, date = null;
			LinkedList<Clothes> list = new LinkedList<Clothes>();
			int orderID = 0, shippingSpeed = 0;
			int counter = 0;
			while ((strLine = br.readLine()) != null || counter == 7) {
				// if(strLine.trim().length() > 0) {
				if (counter == 0) {
					temp = strLine;
				}
				if (counter == 1) {
					orderID = Integer.parseInt(strLine);
				}
				if (counter == 2) {
					firstName = strLine;
				}
				if (counter == 3) {
					lastName = strLine;
				}
				if (counter == 4) {
					date = strLine;
				}
				if (counter == 5) {
					String split[] = strLine.split(",");
					LinkedList<Clothes> tempList = new LinkedList<Clothes>();
					for (int i = 0; i < split.length; i++) {
						String split2[] = split[i].split(" ");
						Clothes clothing = new Clothes();
						clothing.setProductName(split2[0] + " " + split2[1] + " " + split2[2]);
						clothing = clothes.search(clothing, ClothesPrimaryCompare);
						tempList.addLast(clothing);
					}
					list = tempList;
				}
				if (counter == 6) {
					if (strLine.equals("Standard")) {
						shippingSpeed = 1;
					} else if (strLine.equals("Rush")) {
						shippingSpeed = 2;
					} else if (strLine.equals("Overnight")) {
						shippingSpeed = 3;
					}
				}
				if (counter == 7) {
					Customer c = new Customer("", "", firstName, lastName, "", "", "", "");
					// insert orders into existing customer objects in ht?
					Order order = new Order(orderID, date, c, list, shippingSpeed);
					unshippedHeap.insert(order, PriorityComparator);
					c.getUnshippedOrders().addLast(order);
					counter = 0;
				}
				counter++;
				// }
			}
			in.close();
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
		}

		unshippedHeap.sort(PriorityComparator);
		
		try {
			FileInputStream fstream = new FileInputStream("ShippedOrders.txt");
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine, firstName = null, lastName = null, date = null;
			LinkedList<Clothes> list = new LinkedList<Clothes>();
			int orderID = 0, shippingSpeed = 0;
			int counter = 0;
			while ((strLine = br.readLine()) != null || counter == 7) {
				// if(strLine.trim().length() > 0) {
				if (counter == 0) {
					temp = strLine;
				}
				if (counter == 1) {
					orderID = Integer.parseInt(strLine);
				}
				if (counter == 2) {
					firstName = strLine;
				}
				if (counter == 3) {
					lastName = strLine;
				}
				if (counter == 4) {
					date = strLine;
				}
				if (counter == 5) {
					String split[] = strLine.split(",");
					LinkedList<Clothes> tempList = new LinkedList<Clothes>();
					for (int i = 0; i < split.length; i++) {
						String split2[] = split[i].split(" ");
						Clothes clothing = new Clothes();
						clothing.setColor(split2[0]);
						clothing.setMaterial(split2[1]);
						clothing.setProductName(split2[0] + " " + split2[1] + " " + split2[2]);
						clothing = clothes.search(clothing, ClothesPrimaryCompare);
						tempList.addLast(clothing);
					}
					list = tempList;
				}
				if (counter == 6) {
					if (strLine.equals("Standard")) {
						shippingSpeed = 1;
					} else if (strLine.equals("Rush")) {
						shippingSpeed = 2;
					} else if (strLine.equals("Overnight")) {
						shippingSpeed = 3;
					}
				}
				if (counter == 7) {
					Customer c = new Customer("", "", firstName, lastName, "", "", "", "");
					// insert orders into existing customer objects in ht?
					Order order = new Order(orderID, date, c, list, shippingSpeed);
					shippedHeap.insert(order, PriorityComparator);
					c.getShippedOrders().addLast(order);
					counter = 0;
				}
				counter++;
				// }
			}
			in.close();
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
		}

		shippedHeap.sort(PriorityComparator);

		do {

			loginType = input.nextInt();
			int customerType;

			if (loginType == 1) {

				System.out.println("\nEnter 1 to login with an existing account \n"
						+ "Enter 2 to sign up and make a new account\n" + "Enter 3 to login as a guest\n");

				// do {
				Customer c1 = new Customer();
				customerType = input.nextInt();
				input.nextLine();
				boolean found = false;

				if (customerType == 1) {
					do {
						System.out.print("\nPlease enter your username: ");
						temp = input.nextLine();
						c1.setUserName(temp);
						System.out.print("\nPlease enter your password: ");
						temp = input.nextLine();
						c1.setPassword(temp);

						int bucket = ht.find(c1);

						if (bucket != -1) {
							found = true;
							c1 = ht.getCustomer(bucket, c1.userName, c1.password);
						} else {
							System.out.println("\nUsername or password doesn't exist. Please try again.");
						}

						// PUT ORDERS INTO CUSTOMER OBJECTS
						for(int i = 0; i < unshippedHeap.getHeapSize(); i++) {
							Order order = unshippedHeap.getElement(i);
							if(order.getCustomer().getFirstName().equals(c1.getFirstName()) && order.getCustomer().getLastName().equals(c1.getLastName())) {
								c1.getUnshippedOrders().addLast(order);
							}
						}
						
						for(int i = 0; i < shippedHeap.getHeapSize(); i++) {
							Order order = shippedHeap.getElement(i);
							if(order.getCustomer().getFirstName().equals(c1.getFirstName()) && order.getCustomer().getLastName().equals(c1.getLastName())) {
								c1.getShippedOrders().addLast(order);
							}
						}

					} while (!found);
				}

				else if (customerType == 2) {
					System.out.print("\nPlease enter your new username: ");
					temp = input.nextLine();
					c1.setUserName(temp);
					System.out.print("\nPlease enter your new password: ");
					temp = input.nextLine();
					c1.setPassword(temp);
					System.out.print("\nPlease enter your first name: ");
					temp = input.nextLine();
					c1.setFirstName(temp);
					System.out.print("\nPlease enter your last name: ");
					temp = input.nextLine();
					c1.setLastName(temp);
					System.out.print("\nPlease enter your address: ");
					temp = input.nextLine();
					c1.setAddress(temp);
					System.out.print("\nCity: ");
					temp = input.nextLine();
					c1.setCity(temp);
					System.out.print("\nState: ");
					temp = input.nextLine();
					c1.setState(temp);
					System.out.print("\nZip Code: ");
					temp = input.nextLine();
					c1.setZip(temp);

					ht.add(c1);

					try {
						PrintWriter out = new PrintWriter(new FileOutputStream("Customer.txt", true));
						out.println("\n" + c1.getUserName() + "\n" + c1.getPassword() + "\n" + c1.getFirstName() + "\n"
								+ c1.getLastName() + "\n" + c1.getAddress() + "\n" + c1.getCity() + "\n" + c1.getState()
								+ "\n" + c1.getZip());
						out.close();
					} catch (Exception e) {
						System.err.println("Error: " + e.getMessage());
					}

					System.out.println("\nDone! Your account was successfully setup!");
					System.out.println("Thank you for becoming a member of CIS 22C Clothing Store");
				}

				else if (customerType == 3) {
					c1.setUserName("Guest");
					c1.setPassword("tempPass");
					c1.setFirstName("");
					c1.setLastName("");
					c1.setAddress("");
					c1.setCity("");
					c1.setState("");
					c1.setZip("");

				}

				// }while(customerType != 1 && customerType != 2 && customerType !=3);

				int option = 10;
				System.out.println("\nWhat would you like to do today?\n");
				while (option != 0) {
					System.out.println("1) Search Clothes \n");
					System.out.println("2) View all available Clothes\n");
					System.out.println("3) Place an Order \n");
					System.out.println("4) View Purchases \n");
					System.out.println("0) Quit \n");
					System.out.print("\nPlease select an option by typing the number: ");
					option = input.nextInt();

					if (option == 1) {
						int keyChoice = 0;
						System.out.println("\nHow would you like to search for your item?\n");
						System.out.println("1) Name");
						System.out.println("2) Price\n");
						keyChoice = input.nextInt();
						if (keyChoice == 1) {
							String userInput = "";
							System.out.println("\nWhich clothing item would you like to take a look at?\n");
							input.nextLine();
							userInput = input.nextLine();
							Clothes tempClothes = new Clothes(userInput, "", "", "", 0, "", 0);
							tempClothes = clothes.search(tempClothes, ClothesPrimaryCompare);
							System.out.println("\n" + tempClothes.toString());
						} else if (keyChoice == 2) {
							Double userInput = 0.0;
							System.out.println(
									"\nWhat is the price of the clothing item would you like to take a look at?\n");
							input.nextLine();
							userInput = input.nextDouble();
							Clothes tempClothes = new Clothes("", "", "", "", 0, "", userInput);
							tempClothes = clothes.search(tempClothes, ClothesSecondaryCompare);
							System.out.println("\n" + tempClothes.toString());
						}
						System.out.println("\nWhat else would you like to do today?\n");
					}

					else if (option == 2) {
						int keyChoice = 0;
						System.out.println("\nHow would you like to display for the items?\n");
						System.out.println("1) Sort by Name");
						System.out.println("2) Sort by Price\n");
						keyChoice = input.nextInt();
						if (keyChoice == 1) {
							System.out.print("\n" + clothes.inOrderString());
						} else if (keyChoice == 2) {
							System.out.print("\n" + clothesSecondary.inOrderString());
						}
						System.out.println("\nWhat else would you like to do today?\n");
					}

					else if (option == 3) {
						String userInput = "";
						int num = 0;
						LinkedList<Clothes> cart = new LinkedList<Clothes>();

						if (customerType == 3) {
							System.out.print("\nPlease enter your first name: ");
							input.nextLine();
							temp = input.nextLine();
							c1.setFirstName(temp);
							System.out.print("\nPlease enter your last name: ");
							temp = input.nextLine();
							c1.setLastName(temp);
							System.out.print("\nPlease enter your address: ");
							temp = input.nextLine();
							c1.setAddress(temp);
							System.out.print("\nCity: ");
							temp = input.nextLine();
							c1.setCity(temp);
							System.out.print("\nState: ");
							temp = input.nextLine();
							c1.setState(temp);
							System.out.print("\nZip Code: ");
							temp = input.nextLine();
							c1.setZip(temp);
						}

						System.out.println("\nHow many items would you like to purchase?\n");
						num = input.nextInt();
						input.nextLine();

						for (int i = 0; i < num; i++) {
							System.out.println("\n\nWhat would you like to purchase? (Enter specific product name)");
							userInput = input.nextLine();
							Clothes purchase = new Clothes(userInput, "", "", "", 0, "", 0);
							purchase = clothes.search(purchase, ClothesPrimaryCompare);
							cart.addLast(purchase);
						}

						System.out.println("\nPlease select your preferred shipping option\n");
						System.out.println("1) Overnight Shipping");
						System.out.println("2) Rush Shiping");
						System.out.println("3) Standard Shipping");
						num = input.nextInt();

						String date = new SimpleDateFormat("MM/dd/yyyy").format(new Date());
						Random rand = new Random(); // instance of random class
						int upperbound = 100000;
						int orderId = rand.nextInt(upperbound);

						Order newOrder = new Order(orderId, date, c1, cart, num);
						c1.getUnshippedOrders().addLast(newOrder);
						unshippedHeap.insert(newOrder, PriorityComparator);

						// USING HEAP TO PLACE ORDER AND WRITE IN TXT FILE

						try {
							PrintWriter out = new PrintWriter(new FileOutputStream("UnshippedOrders.txt", true));
							out.println("\n" + newOrder.toString());
							out.close();
						} catch (Exception e) {
							System.err.println("Error: " + e.getMessage());
						}

						System.out.println("\nThank you for your purchase! Your order is on it's way\n");
						System.out.println("\nWhat else would you like to do today?\n");

					} else if (option == 4) {
						int num = 0;
						System.out.println("\nWhich orders would you like to view?\n");
						System.out.println("1) Shipped Orders");
						System.out.println("2) Unshipped Orders");
						input.nextLine();
						num = input.nextInt();

						if (num == 1) {
							System.out.println("\n" + c1.getShippedOrders().toString());
						} else if (num == 2) {
							System.out.println("\n" + c1.getUnshippedOrders().toString());
						}

						System.out.println("\nWhat else would you like to do today?\n");

					}

					else if (option == 0) {
						System.out.println("\nThank you for using our program! We'll miss you :(");
						try {
							PrintWriter out = new PrintWriter(new FileOutputStream("Customer.txt"));
							out.println(ht.toString());
							out.close();
						} catch (Exception e) {
							System.err.println("Error: " + e.getMessage());
						}
						try {
							PrintWriter out = new PrintWriter(new FileOutputStream("UnshippedOrders.txt"));
							out.println(unshippedHeap.toString());
							out.close();
						} catch (Exception e) {
							System.err.println("Error: " + e.getMessage());
						}
						try {
							PrintWriter out = new PrintWriter(new FileOutputStream("ShippedOrders.txt"));
							out.println(shippedHeap.toString());
							out.close();
						} catch (Exception e) {
							System.err.println("Error: " + e.getMessage());
						}
						try {
							PrintWriter out = new PrintWriter(new FileOutputStream("Clothes.txt"));
							out.println(clothes.inOrderString());
							out.close();
						} catch (Exception e) {
							System.err.println("Error: " + e.getMessage());
						}
						// WRITE TO FILE
					}

				}
			}

			else if (loginType == 2) {
				HashTable<Employee> ht2 = new HashTable<Employee>(20);

				try {
					FileInputStream fstream = new FileInputStream("Employee.txt");
					DataInputStream in = new DataInputStream(fstream);
					BufferedReader br = new BufferedReader(new InputStreamReader(in));
					String strLine, username = null, password = null, firstName = null, lastName = null,
							manager = "Manager";
					boolean isManager = false;
					int counter = 1;
					while ((strLine = br.readLine()) != null || counter == 6) {
						// if(strLine.trim().length() > 0 || counter == 6) {
						if (counter == 1) {
							username = strLine;
						}
						if (counter == 2) {
							password = strLine;
						}
						if (counter == 3) {
							firstName = strLine;
						}
						if (counter == 4) {
							lastName = strLine;
						}
						if (counter == 5) {
							if (manager.equals(strLine)) {
								isManager = true;
							} else {
								isManager = false;
							}
						}
						if (counter == 6) {
							Employee employee = new Employee(username, password, firstName, lastName, isManager);
							ht2.add(employee);
							counter = 0;
						}
						counter++;
						// }
					}
					in.close();
				} catch (Exception e) {
					System.err.println("Error: " + e.getMessage());
				}

				Employee e1 = new Employee();
				boolean found = false;

				do {
					input.nextLine();
					System.out.print("\nPlease enter your username: ");
					temp = input.nextLine();
					e1.setUserName(temp);
					System.out.print("\nPlease enter your password: ");
					temp = input.nextLine();
					e1.setPassword(temp);

					int bucket = ht2.find(e1);

					if (bucket != -1) {
						found = true;
						e1 = ht2.getEmployee(bucket, e1.userName, e1.password);
					} else {
						System.out.println("\nUsername or password doesn't exist. Please try again.");
					}
				} while (!found);

				int employeeOption = -1;
				while (employeeOption != 0) {
					System.out.println("\nWhat would you like to do today?\n");
					System.out.println("1) Search for an order \n");
					System.out.println("2) View Order with highest priority\n");
					System.out.println("3) View all orders \n");
					System.out.println("4) Ship an order \n");
					if (e1.isManager()) {
						System.out.println("5) Add new product \n");
						System.out.println("6) Change product information \n");
						System.out.println("7) Remove product \n");
					}
					System.out.println("0) Quit \n");
					System.out.print("\nPlease select an option by typing the number: ");
					employeeOption = input.nextInt();

					switch (employeeOption) {
					case 1:
						int employeeSearch = 0;
						System.out.println("\nHow do you want to search the order?\n");
						System.out.println("\n1)Order id");
						System.out.println("2)Customer's First and Last name\n");
						employeeSearch = input.nextInt();

						if (employeeSearch == 1) {
							// search in heap;
							int orderID = 0;
							System.out.println("\nPlease input your order ID: ");
							orderID = input.nextInt();
							
							for(int i = 0; i < unshippedHeap.getHeapSize(); i++) {
								Order order = unshippedHeap.getElement(i);
								if(order.getOrderId() == orderID) {
									System.out.println("\n" + order.toString());
								}
							}
							
							for(int i = 0; i < shippedHeap.getHeapSize(); i++) {
								Order order = shippedHeap.getElement(i);
								if(order.getOrderId() == orderID) {
									System.out.println("\n" + order.toString());
								}
							}

						} else if (employeeSearch == 2) {
							// search in heap using customer object
							input.nextLine();
							String first_name = "";
							String last_name = "";
							System.out.println("\nPlease input your first name: ");
							first_name = input.nextLine();
							System.out.println("\nPlease input your name: ");
							last_name = input.nextLine();
							
							for(int i = 0; i < unshippedHeap.getHeapSize(); i++) {
								Order order = unshippedHeap.getElement(i);
								if(order.getCustomer().getFirstName().equals(first_name) && order.getCustomer().getLastName().equals(last_name)) {
									System.out.println("\n" + order.toString());
								}
							}
							for(int i = 0; i < shippedHeap.getHeapSize(); i++) {
								Order order = shippedHeap.getElement(i);
								if(order.getCustomer().getFirstName().equals(first_name) && order.getCustomer().getLastName().equals(last_name)) {
									System.out.println("\n" + order.toString());
								}
							}
						}
						break;
					case 2:
						// use getmax to print the order object
						unshippedHeap.sort(PriorityComparator);
						System.out.println("\n" + unshippedHeap.getMax().toString());
						break;
					case 3:
						// heap toString
						System.out.println("\n" + shippedHeap.toString());
						System.out.println("\n" + unshippedHeap.toString());
						break;
					case 4:
						// insert the max heap object to shipped linkedlist in customer
						unshippedHeap.sort(PriorityComparator);
						shippedHeap.sort(PriorityComparator);
						Order order = unshippedHeap.getMax();
						// heap remove the max
						unshippedHeap.remove(0, PriorityComparator);
						shippedHeap.insert(order, PriorityComparator);
						System.out.println("\nOrder with highest prioirty has been shipped!\n");
						break;
					case 5:
						// BST insert new clothes object
						String data = "";
						int num = 0;
						double price = 0;
						Clothes newClothes = new Clothes();
						System.out.println("\nPlease insert data for the new product");
						System.out.println("\nProduct Name: ");
						input.nextLine();
						data = input.nextLine();
						newClothes.setProductName(data);
						
						System.out.println("\nSize Available: ");
						data = input.nextLine();
						newClothes.setSize(data);
						
						System.out.println("\nMade In: ");
						data = input.nextLine();
						newClothes.setMadeIn(data);
						
						System.out.println("\nColor: ");
						data = input.nextLine();
						newClothes.setColor(data);
						
						System.out.println("\nMaterial: ");
						data = input.nextLine();
						newClothes.setMaterial(data);
						
						System.out.println("\nNumber in Stock: ");
						num = input.nextInt();
						newClothes.setNumInStock(num);
						
						System.out.println("\nPrice: ");
						price = input.nextDouble();
						newClothes.setPrice(price);
						
						clothes.insert(newClothes, ClothesPrimaryCompare);
						clothesSecondary.insert(newClothes, ClothesSecondaryCompare);
						break;
					case 6:
						// BST search for the product
						// change info on a clothes object within the BST
						input.nextLine();
						String name = "";
						int choice = 0;
						double newPrice = 0;
						System.out.println("\nPlease type the name of the product you want to update:");
						name = input.nextLine();
						Clothes toUpdate = new Clothes (name, "", "", "", 0, "", 0);
						toUpdate = clothes.search(toUpdate, ClothesPrimaryCompare);
						clothes.remove(toUpdate, ClothesPrimaryCompare);
						clothesSecondary.remove(toUpdate, ClothesSecondaryCompare);
						
						System.out.println("\nWhat would you like to update about this product?\n\n");
						System.out.println("1) Update Price \n");
						System.out.println("2) Update Name\n");
						System.out.println("3) Update Stock Number \n");

						choice = input.nextInt();
						
						if(choice == 1) {
							System.out.println("\nType what price you would like to change the product to: ");
							newPrice = input.nextDouble();
							
							toUpdate.setPrice(newPrice);
						}
						else if (choice == 2) {
							System.out.println("\nType what Name you would like to change the product to: ");
							input.nextLine();
							name = input.nextLine();
							
							toUpdate.setProductName(name);
						}
						else if (choice == 3) {
							System.out.println("\nPlease type the new number of stock: ");
							choice = input.nextInt();
							
							toUpdate.setNumInStock(choice);
						}
						clothes.insert(toUpdate, ClothesPrimaryCompare);
						clothesSecondary.insert(toUpdate, ClothesSecondaryCompare);
						break;
					case 7:
						input.nextLine();
						// BST remove
						System.out.println("\nPlease type the name of the product you want to remove:");
						name = input.nextLine();
						Clothes toRemove = new Clothes (name, "", "", "", 0, "", 0);
						clothes.remove(toRemove, ClothesPrimaryCompare);
						break;
					case 0:
						//WRITE TO FILE
						try {
							PrintWriter out = new PrintWriter(new FileOutputStream("Customer.txt"));
							out.println(ht.toString());
							out.close();
						} catch (Exception e) {
							System.err.println("Error: " + e.getMessage());
						}
						try {
							PrintWriter out = new PrintWriter(new FileOutputStream("UnshippedOrders.txt"));
							out.println(unshippedHeap.toString());
							out.close();
						} catch (Exception e) {
							System.err.println("Error: " + e.getMessage());
						}
						try {
							PrintWriter out = new PrintWriter(new FileOutputStream("ShippedOrders.txt"));
							out.println(shippedHeap.toString());
							out.close();
						} catch (Exception e) {
							System.err.println("Error: " + e.getMessage());
						}
						try {
							PrintWriter out = new PrintWriter(new FileOutputStream("Clothes.txt"));
							out.println(clothes.inOrderString());
							out.close();
						} catch (Exception e) {
							System.err.println("Error: " + e.getMessage());
						}
						System.out.println("Thank you for using this interface!");
						break;
					}
				}
			}

		} while (loginType != 1 && loginType != 2);

		input.close();
	}
}
