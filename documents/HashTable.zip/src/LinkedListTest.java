/**
 * @author Jennifer Parrish
 */

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import java.util.NoSuchElementException;

class LinkedListTest {

    @Test
    void testLinkedList() {
        LinkedList<Integer> L = new LinkedList<>();
        assertEquals(0, L.getLength());
    }

    @Test
    void testLinkedListTArray() {
        Integer[] array = null;
        LinkedList<Integer> L = new LinkedList<>(array);
        assertEquals(0, L.getLength());
        array = new Integer[3];
        for(int i = 0; i < array.length; i++) {
            array[i] = i;
        }
        L = new LinkedList<>(array);
        assertEquals(0, L.getFirst());
        assertEquals(2, L.getLast());
        assertEquals(3, L.getLength());
    }

    @Test
    void testCopyLinkedList() {
        LinkedList<String> L1 = new LinkedList<>(new String[] {"A", "B", "C"});
        LinkedList<String> Lnull = null;
        LinkedList<String>  copy = new LinkedList<>(Lnull);
        assertEquals(0, copy.getLength());
        copy = new LinkedList<>(L1);
        assertEquals("A", copy.getFirst());
        assertEquals(L1.toString(), copy.toString());
        //checking for deep copy
        L1.addLast("D");
        assertNotEquals(copy.getLength(), L1.getLength());
                  
    }

    @Test
    void testGetFirst() {
        LinkedList<String> L = new LinkedList<>();
        assertThrows(NoSuchElementException.class, ()->{L.getFirst();});
        L.addLast("A");
        assertEquals("A", L.getFirst());
        L.addFirst("B");
        assertEquals("B", L.getFirst());
        L.positionIterator();
        L.addIterator("C");
        assertEquals("B", L.getFirst());
    }

    @Test
    void testGetLast() {
        LinkedList<String> L = new LinkedList<>();
        assertThrows(NoSuchElementException.class, ()->{L.getLast();});
        L.addFirst("A");
        assertEquals("A", L.getLast());
        L.addLast("B");
        assertEquals("B", L.getLast());
        L.positionIterator();
        L.addIterator("C");
        assertEquals("B", L.getLast());
    }

    @Test
    void testGetIterator() {
        LinkedList<String> L = new LinkedList<>(new String[] {"A", "B", "C"});
        assertThrows(NullPointerException.class, ()->{L.getIterator();});
        L.positionIterator();
        assertEquals("A", L.getIterator());
        L.advanceIterator();
        assertEquals("B", L.getIterator());
    }

    @Test
    void testGetLength() {
        LinkedList<String> L = new LinkedList<>();
        assertEquals(0, L.getLength());
        L = new LinkedList<>(new String[] {"A", "B", "C"});
        assertEquals(3, L.getLength());
    }

    @Test
    void testIsEmpty() {
        LinkedList<String> L = new LinkedList<>();
        assertTrue(L.isEmpty());
        L = new LinkedList<>(new String[] {"A", "B", "C"});
        assertFalse(L.isEmpty()); 
    }

    @Test
    void testOffEnd() {
        LinkedList<String> L = new LinkedList<>();
        assertTrue(L.offEnd());
        L = new LinkedList<>(new String[] {"A", "B", "C"});
        assertTrue(L.offEnd()); 
        L.positionIterator();
        assertFalse(L.offEnd());
        
    }

    @Test
    void testAddFirst() {
        LinkedList<String> L = new LinkedList<>();
        L.addFirst("A");
        assertEquals("A", L.getFirst());
        L.addFirst("B");
        assertEquals("B", L.getFirst());
        L = new LinkedList<>(new String[] {"A", "B", "C"});
        L.addFirst("Z");
        assertEquals("Z", L.getFirst());
    }

    @Test
    void testAddLast() {
        LinkedList<String> L = new LinkedList<>();
        L.addLast("A");
        assertEquals("A", L.getFirst());
        assertEquals("A", L.getLast());
        L.addLast("B");
        assertEquals("B", L.getLast());
        L = new LinkedList<>(new String[] {"A", "B", "C"});
        L.addLast("Z");
        assertEquals("Z", L.getLast());
    }

    @Test
    void testAddIterator() {
        LinkedList<String> L = new LinkedList<>();
        assertThrows(NullPointerException.class, ()->{L.addIterator("A");});
        LinkedList<String> L1 = new LinkedList<>(new String[] {"A", "B", "C"});
        assertThrows(NullPointerException.class, ()->{L1.addIterator("Z");});
        L1.positionIterator();
        L1.addIterator("Z");
        assertEquals(4, L1.getLength());
        L1.advanceIterator();
        assertEquals("Z", L1.getIterator());
        L1.advanceIterator();
        L1.addIterator("Z");
        assertEquals("B", L1.getIterator());
        L1.advanceIterator();
        L1.advanceIterator();
        L1.addIterator("X");
        assertEquals("X", L1.getLast());
    }

    @Test
    void testRemoveFirst() {
        LinkedList<String> L = new LinkedList<>();
        assertThrows(NoSuchElementException.class, ()->{L.removeFirst();});
        L.addFirst("Z");
        L.positionIterator();
        L.removeFirst();
        assertTrue(L.isEmpty());
        assertThrows(NoSuchElementException.class, ()->{L.getFirst();});
        assertThrows(NoSuchElementException.class, ()->{L.getLast();});
        assertThrows(NullPointerException.class, ()->{L.getIterator();});
        LinkedList<String> L1 = new LinkedList<>(new String[] {"A", "B", "C"});
        L1.positionIterator();
        L1.removeFirst();
        assertTrue(L1.offEnd());
        assertEquals("B", L1.getFirst());
        assertEquals(2, L1.getLength());
        assertThrows(NullPointerException.class, ()->{L.getIterator();});
    }

    @Test
    void testRemoveLast() {
        LinkedList<String> L = new LinkedList<>();
        assertThrows(NoSuchElementException.class, ()->{L.removeLast();});
        L.addLast("Z");
        L.positionIterator();
        L.removeLast();
        assertTrue(L.isEmpty());
        assertThrows(NoSuchElementException.class, ()->{L.getFirst();});
        assertThrows(NoSuchElementException.class, ()->{L.getLast();});
        assertThrows(NullPointerException.class, ()->{L.getIterator();});
        LinkedList<String> L1 = new LinkedList<>(new String[] {"A", "B", "C"});
        L1.positionIterator();
        L1.advanceIterator();
        L1.advanceIterator();
        L1.removeLast();
        assertTrue(L1.offEnd());
        assertEquals("B", L1.getLast());
        assertEquals(2, L1.getLength());
        assertThrows(NullPointerException.class, ()->{L.getIterator();});
    }

    @Test
    void testRemoveIterator() {
        LinkedList<String> L = new LinkedList<>();
        assertThrows(NullPointerException.class, ()->{L.removeIterator();});
        L.addFirst("A");
        assertThrows(NullPointerException.class, ()->{L.removeIterator();});
        L.positionIterator();
        L.removeIterator();
        assertTrue(L.isEmpty());
        assertTrue(L.offEnd());
        assertThrows(NoSuchElementException.class, ()->{L.getFirst();});
        assertThrows(NoSuchElementException.class, ()->{L.getLast();});
        assertThrows(NullPointerException.class, ()->{L.getIterator();});
        LinkedList<String> L1 = new LinkedList<>(new String[] {"A", "B", "C", "D"});
        L1.positionIterator();
        L1.removeIterator();
        assertTrue(L1.offEnd());
        assertEquals("B", L1.getFirst());
        L1.positionIterator();
        L1.advanceIterator();
        L1.removeIterator();
        assertTrue(L1.offEnd());
        assertEquals(2, L1.getLength());
        L1.positionIterator();
        L1.advanceIterator();
        L1.removeIterator();
        assertTrue(L1.offEnd());
        assertEquals(1, L1.getLength());
        assertEquals("B", L1.getFirst());
        assertEquals("B", L1.getLast());
    }

    @Test
    void testPositionIterator() {
        LinkedList<String> L = new LinkedList<>();
        L.positionIterator();
        assertTrue(L.offEnd());
        L = new LinkedList<>(new String[] {"!", "?", "."});
        L.positionIterator();
        assertEquals("!", L.getIterator());
    }

    @Test
    void testAdvanceIterator() {
        LinkedList<String> L = new LinkedList<>(new String[] {"!", "?", "."});
        assertThrows(NullPointerException.class, ()->{L.advanceIterator();});
        L.positionIterator();
        L.advanceIterator();
        assertEquals("?", L.getIterator());
        L.advanceIterator();
        assertEquals(".", L.getIterator());
        L.advanceIterator();
        assertTrue(L.offEnd());
        assertThrows(NullPointerException.class, ()->{L.advanceIterator();});
    }

    @Test
    void testReverseIterator() {
        LinkedList<String> L = new LinkedList<>(new String[] {"!", "?", "."});
        assertThrows(NullPointerException.class, ()->{L.reverseIterator();});
        L.positionIterator();
        L.advanceIterator();
        L.reverseIterator();
        assertEquals("!", L.getIterator());
        L.reverseIterator();
        assertTrue(L.offEnd());
        assertThrows(NullPointerException.class, ()->{L.advanceIterator();});
    }

    @Test
    void testToString() {
        LinkedList<String> L = new LinkedList<>(new String[] {"!", "?", "."});
        assertEquals("! ? . \n", L.toString());
        L = new LinkedList<>();
        assertEquals("\n", L.toString());
    }

    @Test
    void testEquals() {
        LinkedList<String> nullList = new LinkedList<>();
        LinkedList<Integer> iList = new LinkedList<>();
        LinkedList<String> sList1 = new LinkedList<>(new String[] {"!", "?", "."});
        LinkedList<String> sList2 = new LinkedList<>(new String[] {"!", "?", ".", ","});
        LinkedList<String> sList3 = new LinkedList<>(new String[] {"!", "?", ")"});
        LinkedList<String> sList = new LinkedList<>(new String[] {"!", "?", "."});
        
        assertFalse(sList1.equals(nullList));
        assertFalse(sList1.equals(iList));
        assertFalse(sList1.equals(sList2));
        assertFalse(sList1.equals(sList3));
        assertTrue(sList1.equals(sList));
        /* Not used for grading:
        LinkedList<String> sList5 = new LinkedList<>(new String[] {"!", null, "."});
        LinkedList<String> sList4 = new LinkedList<>(new String[] {"!", null, "."});
        assertTrue(sList4.equals(sList5));
        assertTrue(sList5.equals(sList4));
        assertFalse(sList.equals(sList4));
        assertFalse(sList4.equals(sList));*/
        
    }

    @Test
    void testZipperLists() {
        LinkedList<String> nullList = new LinkedList<>();
        LinkedList<String> iList = new LinkedList<>();
        LinkedList<String> sList1 = new LinkedList<>(new String[] {"!", "?", "."});
        LinkedList<String> sList2 = new LinkedList<>(new String[] {"!", "?", ".", ","});
        
        assertEquals(sList1.zipperLists(nullList).toString(), sList1.toString());
        assertEquals(iList.zipperLists(sList1).toString(), sList1.toString());
        LinkedList<String> temp = sList1.zipperLists(sList2);
        assertEquals(sList1.toString(), "! ? . \n");
        assertEquals(sList2.toString(), "! ? . , \n");
        assertEquals(temp.toString(), "! ! ? ? . . , \n");
        
        temp = sList2.zipperLists(sList1);
        assertEquals(sList1.toString(), "! ? . \n");
        assertEquals(sList2.toString(), "! ? . , \n");
        assertEquals(temp.toString(), "! ! ? ? . . , \n");
        
    }
    
    @Test
    void testIsReversible() {
        LinkedList<Integer> nums = new LinkedList<>();
        assertTrue(nums.isReversible());
        nums.addFirst(1);
        assertTrue(nums.isReversible());
        nums = new LinkedList<>(new Integer[] {1, 2, 3, 2, 1});
        assertTrue(nums.isReversible());
        nums.positionIterator();
        nums.advanceIterator();
        nums.addIterator(3);
        assertTrue(nums.isReversible());
        nums.advanceIterator();
        nums.addIterator(4);
        assertTrue(nums.isReversible());
        nums.addIterator(5);
        assertFalse(nums.isReversible());
        
        LinkedList<String> letters = new LinkedList<>(new String[] {"A", "B", "B", "A"});
        assertTrue(letters.isReversible());
        letters.addFirst(new String("D"));
        letters.addLast("D");
        assertTrue(letters.isReversible());
        letters.removeLast();
        assertFalse(letters.isReversible());
        
    }
	@Test
    void testGetIteratorIndex() {
        LinkedList<String> sList = new LinkedList<>(new String[] {"!", "?", ".", ","});
        assertThrows(NullPointerException.class, ()->{sList.getIteratorIndex();});
        sList.positionIterator();
        assertEquals(0, sList.getIteratorIndex());
        sList.advanceIterator();
        sList.advanceIterator();
        assertEquals(2, sList.getIteratorIndex());
        sList.advanceIterator();
        assertEquals(3, sList.getIteratorIndex());
        sList.advanceIterator();
        assertThrows(NullPointerException.class, ()->{sList.getIteratorIndex();});
        
    }
    
    @Test
    void testFindIndex() {
        LinkedList<Integer> iList = new LinkedList<>();
        assertEquals(-1, iList.findIndex(4));
        LinkedList<String> sList = new LinkedList<>(new String[] {"!", "?", ".", ","});
        assertEquals(0, sList.findIndex("!"));
        assertEquals(1, sList.findIndex("?"));
        assertThrows(NullPointerException.class, ()->{sList.getIterator();});
        assertEquals(2, sList.findIndex("."));
        assertEquals(3, sList.findIndex(","));
        
    }
    
    @Test 
    void testAdvanceIteratorToIndex() {
        LinkedList<Integer> iList = new LinkedList<>();
        assertThrows(NullPointerException.class, ()->{iList.advanceIteratorToIndex(3);});
        LinkedList<String> sList = new LinkedList<>(new String[] {"!", "?", ".", ","});
        assertThrows(NullPointerException.class, ()->{sList.advanceIteratorToIndex(2);});
        sList.positionIterator();
        sList.advanceIteratorToIndex(2);
        assertEquals(".", sList.getIterator());
        assertThrows(NullPointerException.class, ()->{sList.advanceIteratorToIndex(3);});
        sList.positionIterator();
        sList.advanceIteratorToIndex(3);
        assertEquals(",", sList.getIterator());
        sList.positionIterator();
        sList.advanceIteratorToIndex(0);
        assertEquals("!", sList.getIterator());
        
    }
}
